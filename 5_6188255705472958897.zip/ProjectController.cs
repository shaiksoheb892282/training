using ASP_EF_App1.DAL;
using ASP_EF_App1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ASP_EF_App1.Controllers      //DO NOT change the namespace name
{
    public class ProjectController : Controller //DO NOT change the class name
    {
        // Implement 'ProjectDetail' action
      // Implement 'ProjectDetail' action with HttpPost
      ProjectContext context= new ProjectContext();
      public ActionResult ProjectDetail()
      {
          return View("AddProjectDetails");
      }
      [HttpPost]
      public ActionResult ProjectDetail(Project p)
      {
          context.Projects.Add(p);
          context.SaveChanges();
          return View("ViewProjectDetails",p);
      }
    
    }
}